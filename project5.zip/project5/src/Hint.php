<?php

namespace Proejct5;

class Hint
{
    private string $hint;

    public function __construct(string $hint)
    {
        $this->hint = $hint;
    }
}