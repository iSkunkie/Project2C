<?php

namespace Proejct5;

class HintList
{
    private array $hints = [];

    public function addHint(Hint $hint)
    {
        $this->hints[] = $hint;
    }

    public function getHints()
    {

    }

    public function getRandomHint()
    {

    }
}