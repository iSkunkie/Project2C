<?php

namespace Proejct5;

class Turn
{
    private int $guessiceHoles;
    private int $guessPolarBears;
    private int $guessPenguins;

}